﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ASK_SDK
{
    public enum TranslationEnum
    {
        ChineseSimplified = 40,
        Enginlish = 10,
    }

}

