﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace ASK_SDK
{
    public class FieldLNGConfig
    {
        [Translation(TranslationEnum.Enginlish, "Language1")]
        [Translation(TranslationEnum.ChineseSimplified, "语言设置")]
        public static string language_str = "";

        #region Model
        [Translation(TranslationEnum.Enginlish, "Language2")]
        [Translation(TranslationEnum.ChineseSimplified, "登录成功！")]
        public static string success_msg_str="";

        [Translation(TranslationEnum.Enginlish, "Language3")]
        [Translation(TranslationEnum.ChineseSimplified, "登录失败！")]
        public static string failed_msg_str = "";

        [Translation(TranslationEnum.Enginlish, "Language4")]
        [Translation(TranslationEnum.ChineseSimplified, "尊贵的蓝色权限")]
        public static string idAuthority_str = "";
        #endregion

        #region Utils
        [Translation(TranslationEnum.ChineseSimplified, "文件或者目录名称：")]
        public static string file_or_dir_str = "";

        [Translation(TranslationEnum.ChineseSimplified, "不存在，请检查")]
        public static string no_value_check_str = " ";

        #endregion

        #region Window
        //asset wiondw
        [Translation(TranslationEnum.Enginlish, "Language5")]
        [Translation(TranslationEnum.ChineseSimplified, "化身")]
        public static string avatar_str = "";

        [Translation(TranslationEnum.Enginlish, "Language6")]
        [Translation(TranslationEnum.ChineseSimplified, "场景")]
        public static string scene_str = "";

        //info window
        [Translation(TranslationEnum.Enginlish, "Language7")]
        [Translation(TranslationEnum.ChineseSimplified, "化身信息")]
        public static string avatar_info_str = "";

        [Translation(TranslationEnum.Enginlish, "Language8")]
        [Translation(TranslationEnum.ChineseSimplified, "场景信息")]
        public static string scene_info_str = "";

        //login window
        [Translation(TranslationEnum.Enginlish, "Language9")]
        [Translation(TranslationEnum.ChineseSimplified, "登录")]
        public static string login_str = "";

        [Translation(TranslationEnum.Enginlish, "Language10")]
        [Translation(TranslationEnum.ChineseSimplified, "注销")]
        public static string unlogin_str = "";

        [Translation(TranslationEnum.Enginlish, "Language11")]
        [Translation(TranslationEnum.ChineseSimplified, "账号:")]
        public static string id_str = "";

        [Translation(TranslationEnum.Enginlish, "Language12")]
        [Translation(TranslationEnum.ChineseSimplified, "密码:")]
        public static string psd_str = "";

        //main window
        [Translation(TranslationEnum.Enginlish, "Language13")]
        [Translation(TranslationEnum.ChineseSimplified, "打包资源")]
        public static string main_asset_build_str = "";

        [Translation(TranslationEnum.Enginlish, "Language14")]
        [Translation(TranslationEnum.ChineseSimplified, "Astral工具包")]
        public static string main_title_str = "";

        [Translation(TranslationEnum.Enginlish, "Language15")]
        [Translation(TranslationEnum.ChineseSimplified, "填写信息")]
        public static string main_info_str = "";

        [Translation(TranslationEnum.Enginlish, "Language16")]
        [Translation(TranslationEnum.ChineseSimplified, "上传服务器")]
        public static string main_upload_str = "";

        //upload window
        [Translation(TranslationEnum.Enginlish, "Language17")]
        [Translation(TranslationEnum.ChineseSimplified, "打包成功!")]
        public static string upload_build_sccess_str = "";

        [Translation(TranslationEnum.Enginlish, "Language18")]
        [Translation(TranslationEnum.ChineseSimplified, "上传成功!")]
        public static string upload_upload_sccess_str = "";

        [Translation(TranslationEnum.Enginlish, "Language19")]
        [Translation(TranslationEnum.ChineseSimplified, "打包")]
        public static string upload_build_str = "";

        [Translation(TranslationEnum.Enginlish, "Language20")]
        [Translation(TranslationEnum.ChineseSimplified, "上传")]
        public static string upload_load_str = "";

        [Translation(TranslationEnum.Enginlish, "Language21")]
        [Translation(TranslationEnum.ChineseSimplified, "日志信息")]
        public static string upload_log_str = "";

        //b avatar asset info
        //b scene asset info
        [Translation(TranslationEnum.Enginlish, "Language22")]
        [Translation(TranslationEnum.ChineseSimplified, "模型面数")]
        public static string bAvatarAsset_modeCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language23")]
        [Translation(TranslationEnum.ChineseSimplified, "骨骼数量")]
        public static string bAvatarAsset_boneCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language24")]
        [Translation(TranslationEnum.ChineseSimplified, "动态骨骼数量")]
        public static string bAvatarAsset_damBoneCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language25")]
        [Translation(TranslationEnum.ChineseSimplified, "动骨碰撞数量")]
        public static string bAvatarAsset_damBoneCollisionCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language26")]
        [Translation(TranslationEnum.ChineseSimplified, "待定")]
        public static string bAvatarAsset_maybe = "";

        [Translation(TranslationEnum.Enginlish, "Language27")]
        [Translation(TranslationEnum.ChineseSimplified, "化身资产")]
        public static string bAvatarAsset_asset_avatar_str = "";

        [Translation(TranslationEnum.Enginlish, "Language28")]
        [Translation(TranslationEnum.ChineseSimplified, "astralTrigger数量")]
        public static string astralTriggerCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language29")]
        [Translation(TranslationEnum.ChineseSimplified, "镜子数量")]
        public static string mirrorCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language30")]
        [Translation(TranslationEnum.ChineseSimplified, "换衣间数量")]
        public static string changingRoomCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language31")]
        [Translation(TranslationEnum.ChineseSimplified, "场景资产")]
        public static string scene_avatar_str = "";

        [Translation(TranslationEnum.Enginlish, "Language32")]
        [Translation(TranslationEnum.ChineseSimplified, "个")]
        public static string p_num = "";

        [Translation(TranslationEnum.Enginlish, "Language33")]
        [Translation(TranslationEnum.ChineseSimplified, "KB")]
        public static string p_size = "";

        [Translation(TranslationEnum.Enginlish, "Language34")]
        [Translation(TranslationEnum.ChineseSimplified, "面")]
        public static string p_plan = "";

        [Translation(TranslationEnum.Enginlish, "Language35")]
        [Translation(TranslationEnum.ChineseSimplified, "材质球数量")]
        public static string materialCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language36")]
        [Translation(TranslationEnum.ChineseSimplified, "Shader数量")]
        public static string shanderCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language37")]
        [Translation(TranslationEnum.ChineseSimplified, "游戏对象数量")]
        public static string gameobjectCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language38")]
        [Translation(TranslationEnum.ChineseSimplified, "贴图文件大小")]
        public static string texture2dSizeStr = "";

        [Translation(TranslationEnum.Enginlish, "Language39")]
        [Translation(TranslationEnum.ChineseSimplified, "贴图文件数量")]
        public static string texture2dCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language40")]
        [Translation(TranslationEnum.ChineseSimplified, "粒子系统数量")]
        public static string particalSystemCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language41")]
        [Translation(TranslationEnum.ChineseSimplified, "粒子总数")]
        public static string paticalSystemSizeStr = "";

        [Translation(TranslationEnum.Enginlish, "Language42")]
        [Translation(TranslationEnum.ChineseSimplified, "音频组件数量")]
        public static string audioComponentCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language43")]
        [Translation(TranslationEnum.ChineseSimplified, "音频大小")]
        public static string audioComponentSizeStr = "";

        [Translation(TranslationEnum.Enginlish, "Language44")]
        [Translation(TranslationEnum.ChineseSimplified, "视频组件数量")]
        public static string playVideoComponentCountStr = "";

        [Translation(TranslationEnum.Enginlish, "Language45")]
        [Translation(TranslationEnum.ChineseSimplified, "视频大小")]
        public static string playVideoComponentSizeStr = "";

        [Translation(TranslationEnum.Enginlish, "Language46")]
        [Translation(TranslationEnum.ChineseSimplified, "公开")]
        public static string public_str = "";

        [Translation(TranslationEnum.Enginlish, "Language47")]
        [Translation(TranslationEnum.ChineseSimplified, "私有")]
        public static string private_str = "";

        //b scene upload
        //b avatar upload
        [Translation(TranslationEnum.Enginlish, "Language48")]
        [Translation(TranslationEnum.ChineseSimplified, "预览图")]
        public static string preview_picture_str = "";

        [Translation(TranslationEnum.Enginlish, "Language49")]
        [Translation(TranslationEnum.ChineseSimplified, "背景图")]
        public static string bg_picture_str = "";

        [Translation(TranslationEnum.Enginlish, "Language50")]
        [Translation(TranslationEnum.ChineseSimplified, "化身名称")]
        public static string avatar_name_str = "";

        [Translation(TranslationEnum.Enginlish, "Language51")]
        [Translation(TranslationEnum.ChineseSimplified, "文本介绍（140字以内）")]
        public static string avatar_info_tip__str = "";

        [Translation(TranslationEnum.Enginlish, "Language52")]
        [Translation(TranslationEnum.ChineseSimplified, "展示图")]
        public static string plan_picture_str = "";

        [Translation(TranslationEnum.Enginlish, "Language53")]
        [Translation(TranslationEnum.ChineseSimplified, "请回去选择资源!")]
        public static string please_chooise_asset_str = "";

        [Translation(TranslationEnum.Enginlish, "Language54")]
        [Translation(TranslationEnum.ChineseSimplified, "图片拖拽到此")]
        public static string picture_drag_this_str = "";

        [Translation(TranslationEnum.Enginlish, "Language55")]
        [Translation(TranslationEnum.ChineseSimplified, "更新日志")]
        public static string log_update_str = "";

        [Translation(TranslationEnum.Enginlish, "Language56")]
        [Translation(TranslationEnum.ChineseSimplified, "*(使用逗号隔开，不分中英文)")]
        public static string tags_tip_str = "";

        [Translation(TranslationEnum.Enginlish, "Language57")]
        [Translation(TranslationEnum.ChineseSimplified, "状态")]
        public static string status_str = "";

        [Translation(TranslationEnum.Enginlish, "Language58")]
        [Translation(TranslationEnum.ChineseSimplified, "地图名字:")]
        public static string map_name_str = "";

        [Translation(TranslationEnum.Enginlish, "Language59")]
        [Translation(TranslationEnum.ChineseSimplified, "缩略图")]
        public static string thumbnailStr = "";

        [Translation(TranslationEnum.Enginlish, "Language60")]
        [Translation(TranslationEnum.ChineseSimplified, "地图简介")]
        public static string map_introduction_str = "";

        [Translation(TranslationEnum.Enginlish, "Language61")]
        [Translation(TranslationEnum.ChineseSimplified, "视频介绍网址:")]
        public static string video_str = "";

        [Translation(TranslationEnum.Enginlish, "Language62")]
        [Translation(TranslationEnum.ChineseSimplified, "房间最大人数:")]
        public static string max_room_str = "";

        [Translation(TranslationEnum.Enginlish, "Language63")]
        [Translation(TranslationEnum.ChineseSimplified, "地图标签:")]
        public static string map_tags_str = "";

        [Translation(TranslationEnum.Enginlish, "Language64")]
        [Translation(TranslationEnum.ChineseSimplified, "渲染管线:")]
        public static string render_pip_str = "";

        [Translation(TranslationEnum.Enginlish, "Language65")]
        [Translation(TranslationEnum.ChineseSimplified, "场景图片预览")]
        public static string scene_preview_str = "";

        [Translation(TranslationEnum.Enginlish, "Language66")]
        [Translation(TranslationEnum.ChineseSimplified, "场景保存失败!")]
        public static string scene_save_fail_str = "";
        
        #endregion
    }
}
