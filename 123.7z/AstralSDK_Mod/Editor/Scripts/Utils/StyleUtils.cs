﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    public class StyleUtils
    {
        public static GUIStyle GetStyle(string stylestr)
        {
            // 使用系统自带的 "AC Button" 样式作为原型，因为 "AC Button" 本身就具有点击效果了
            GUIStyle style = new GUIStyle(stylestr);

            //// 将样式的点击时的效果图，替换为系统自带的 "flow node 4 on" 样式
            //GUIStyle active = new GUIStyle("flow node 3 on");
            //style.active.background = active.normal.background;

            //// 将平时按钮的效果图，替换为系统自带的 "flow node 4" 样式
            //GUIStyle normal = new GUIStyle("flow node 0");
            //style.normal.background = normal.normal.background;

            //style.onNormal.background = active.normal.background;

            // 参考 "flow node 4" 的内部参数，设置一些图片的参数。
            // 如果不设置的话，则图片会按照原 "AC Button" 的样式进行显示
            // 因为图片不一样，所以会有显示上的问题。
            style.stretchHeight = true;
            style.stretchWidth = true;
            style.border = new RectOffset(11, 11, 11, 15);
            style.margin = new RectOffset(2, 2, 0, 0);
            style.padding = new RectOffset(2, 2, 0, 0);
            style.overflow = new RectOffset(7, 7, 6, 9);

            // 进行文本方面的设置
            style.alignment = TextAnchor.MiddleCenter;
            style.fontSize = 14;
            style.richText = true;

            return style;
        }

        public static GUIStyle GetStyle(string stylestr, TextAnchor textAnchor)
        {
            // 使用系统自带的 "AC Button" 样式作为原型，因为 "AC Button" 本身就具有点击效果了
            GUIStyle style = new GUIStyle(stylestr);

            //// 将样式的点击时的效果图，替换为系统自带的 "flow node 4 on" 样式
            //GUIStyle active = new GUIStyle("flow node 3 on");
            //style.active.background = active.normal.background;

            //// 将平时按钮的效果图，替换为系统自带的 "flow node 4" 样式
            //GUIStyle normal = new GUIStyle("flow node 0");
            //style.normal.background = normal.normal.background;

            //style.onNormal.background = active.normal.background;

            // 参考 "flow node 4" 的内部参数，设置一些图片的参数。
            // 如果不设置的话，则图片会按照原 "AC Button" 的样式进行显示
            // 因为图片不一样，所以会有显示上的问题。
            style.stretchHeight = true;
            style.stretchWidth = true;
            style.border = new RectOffset(11, 11, 11, 15);
            style.margin = new RectOffset(2, 2, 0, 0);
            style.padding = new RectOffset(2, 2, 0, 0);
            style.overflow = new RectOffset(7, 7, 6, 9);

            // 进行文本方面的设置
            style.alignment = textAnchor;
            style.fontSize = 14;
            style.richText = true;

            return style;
        }

        public static GUIStyle GetLine()
        {
            GUIStyle style = new GUIStyle("ProfilerRightPane");

            return style;
        }
    }
}

