﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    public class IconUtils
    {
        private const string duck_path = asset_path +  "duck/";
        private const string duck_bg = asset_path + "bg/";
        private const string eat_path = asset_path + "eat/";
        private const string other_path = asset_path + "other/";
        private const string asset_path = "Assets/AstralSDK_Mod/Editor/Asset/";

        [ImagePath(duck_path + "duck-01.png")]
        public static Texture2D duck_go_2;
        [ImagePath(duck_path + "duck-02.png")]
        public static Texture2D duck_seebook;
        [ImagePath(duck_path + "duck-03.png")]
        public static Texture2D duck_error;
        [ImagePath(duck_path + "duck-04.png")]
        public static Texture2D duck_go_3;
        [ImagePath(duck_path + "duck-05.png")]
        public static Texture2D duck_login_1;
        [ImagePath(duck_path + "duck-06.png")]
        public static Texture2D duck_login;
        [ImagePath(duck_path + "duck-07.png")]
        public static Texture2D duck_go_1;
        [ImagePath(duck_path + "duck-08.png")]
        public static Texture2D duck_love;
        [ImagePath(duck_path + "duck-09.png")]
        public static Texture2D duck_swim;
        [ImagePath(duck_path + "duck-10.png")]
        public static Texture2D duck_happy;
        [ImagePath(duck_path + "duck-11.png")]
        public static Texture2D duck_balloon;
        [ImagePath(duck_path + "duck-12.png")]
        public static Texture2D duck_dance;

        [ImagePath(duck_bg + "login_bg.jpg")]
        public static Texture2D login_bg;

        [ImagePath(eat_path + nameof(spoon) + ".png")]
        public static Texture2D spoon;
        [ImagePath(eat_path + nameof(fork) + ".png")]
        public static Texture2D fork;
        [ImagePath(eat_path + nameof(onion) + ".png")]
        public static Texture2D onion;
        [ImagePath(eat_path + nameof(skewers) + ".png")]
        public static Texture2D skewers;
        [ImagePath(eat_path + nameof(baked_pumpkin_pie) + ".png")]
        public static Texture2D baked_pumpkin_pie;
        [ImagePath(eat_path + nameof(baked_potato_chips) + ".png")]
        public static Texture2D baked_potato_chips;
        [ImagePath(eat_path + nameof(grilled_rice_cake) + ".png")]
        public static Texture2D grilled_rice_cake;
        [ImagePath(eat_path + nameof(roasted_beef) + ".png")]
        public static Texture2D roasted_beef;
        [ImagePath(eat_path + nameof(grilled_corn) + ".png")]
        public static Texture2D grilled_corn;
        [ImagePath(eat_path + nameof(roasted_lettuce) + ".png")]
        public static Texture2D roasted_lettuce;
        [ImagePath(eat_path + nameof(grilled_greens) + ".png")]
        public static Texture2D grilled_greens;
        [ImagePath(eat_path + nameof(roast_lamb) + ".png")]
        public static Texture2D roast_lamb;
        [ImagePath(eat_path + nameof(grilled_wings) + ".png")]
        public static Texture2D grilled_wings;
        [ImagePath(eat_path + nameof(grilled_sausage) + ".png")]
        public static Texture2D grilled_sausage;
        [ImagePath(eat_path + nameof(grilled_eggplant) + ".png")]
        public static Texture2D grilled_eggplant;
        [ImagePath(eat_path + nameof(grilled_shrimp) + ".png")]
        public static Texture2D grilled_shrimp;
        [ImagePath(eat_path + nameof(baked_eggs) + ".png")]
        public static Texture2D baked_eggs;
        [ImagePath(eat_path + nameof(roasted_broccoli) + ".png")]
        public static Texture2D roasted_broccoli;
        [ImagePath(eat_path + nameof(grilled_tofu) + ".png")]
        public static Texture2D grilled_tofu;
        [ImagePath(eat_path + nameof(roasted_peppers) + ".png")]
        public static Texture2D roasted_peppers;
        [ImagePath(eat_path + nameof(roasted_enoki_mushroom) + ".png")]
        public static Texture2D roasted_enoki_mushroom;
        [ImagePath(eat_path + nameof(roasted_gluten) + ".png")]
        public static Texture2D roasted_gluten;
        [ImagePath(eat_path + nameof(roasted_leeks) + ".png")]
        public static Texture2D roasted_leeks;
        [ImagePath(eat_path + nameof(roasted_shiitake_mushrooms) + ".png")]
        public static Texture2D roasted_shiitake_mushrooms;
        [ImagePath(eat_path + nameof(grilled_squid) + ".png")]
        public static Texture2D grilled_squid;
        [ImagePath(eat_path + nameof(grilled_chicken_wings) + ".png")]
        public static Texture2D grilled_chicken_wings;
        [ImagePath(eat_path + nameof(roasted_chicken_drumsticks) + ".png")]
        public static Texture2D roasted_chicken_drumsticks;
        [ImagePath(eat_path + nameof(barbecue) + ".png")]
        public static Texture2D barbecue;
        [ImagePath(eat_path + nameof(spinach) + ".png")]
        public static Texture2D spinach;
        [ImagePath(eat_path + nameof(crab) + ".png")]
        public static Texture2D crab;
        [ImagePath(eat_path + nameof(drink) + ".png")]
        public static Texture2D drink;
        [ImagePath(eat_path + nameof(chili) + ".png")]
        public static Texture2D chili;
        [ImagePath(eat_path + nameof(squid) + ".png")]
        public static Texture2D squid;
        [ImagePath(eat_path + nameof(squid_roll) + ".png")]
        public static Texture2D squid_roll;
        [ImagePath(other_path + nameof(tip) + ".png")]
        public static Texture2D tip;
        [ImagePath(asset_path + "cmd focus.png")]
        public static Texture2D cmd_focus;
    }

}
