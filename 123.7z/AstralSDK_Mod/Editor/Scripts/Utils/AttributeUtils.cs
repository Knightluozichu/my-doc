﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace ASK_SDK
{
    public class AttributeUtils
    {
        public static void GetIconDataAttribute()
        {
            Type type = typeof(IconUtils);

            System.Reflection.FieldInfo[] fieldInfo = type.GetFields();

            foreach (var item in fieldInfo)
            {
                ImagePathAttribute attribute = (ImagePathAttribute)Attribute.GetCustomAttribute(item, typeof(ImagePathAttribute));

                if (attribute != null)
                {
                    var texture = AssetUtils.GetTexture2D(attribute.AssetPath);
                    if (texture != null)
                    {
                        item.SetValue(item, texture);
                    }
                }
            }
        }

        public static void GetTranslationAttribute(TranslationEnum language)
        {
            var type = Activator.CreateInstance<FieldLNGConfig>();// typeof(FieldLNGConfig);

            System.Reflection.FieldInfo[] fieldInfo = typeof(FieldLNGConfig).GetFields();

            foreach (var item in fieldInfo)
            {
                var attribute = (TranslationAttribute[])Attribute.GetCustomAttributes(item, type: typeof(TranslationAttribute));

                foreach (var atr in attribute)
                {
                    if(atr.M_enum == language)
                    {
                        item.SetValue(item, atr.M_str);
                    }
                }
            }
        }
    }
}

