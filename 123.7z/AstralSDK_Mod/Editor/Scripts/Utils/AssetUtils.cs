﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace ASK_SDK
{
    public class AssetUtils
    {

        public static Texture2D GetTexture2D(string path)
        {
            return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }

        //AB
        #region 资源

        #region 制作asset avatar

        //"avatar"
        public static string AssetPrefab(GameObject avatarAssetObj, string outPathDir, string puffix)
        {
            RemoveABLabel();

            GameObject avatarAsset = null;
            string report = string.Empty;

            //排除prefab的错误
            if (PrefabUtility.IsPartOfAnyPrefab(avatarAssetObj))
            {
                PrefabUtility.UnpackPrefabInstance(avatarAssetObj, PrefabUnpackMode.Completely, InteractionMode.UserAction);
            }

            AssetDatabase.Refresh();

            //保存为预制体
            string path = string.Format("{0}/{1}.prefab", Application.dataPath, avatarAssetObj.name);
            avatarAsset = PrefabUtility.SaveAsPrefabAssetAndConnect(avatarAssetObj, path, InteractionMode.UserAction);
            AssetDatabase.Refresh();

            string ab_path = AssetDatabase.GetAssetPath(avatarAsset);

            AssetImporter asset = AssetImporter.GetAtPath(ab_path);

            asset.assetBundleName = avatarAsset.name;

            asset.assetBundleVariant = puffix;

            asset.SaveAndReimport();

            AssetDatabase.Refresh();
            try
            {
               var manifest =  BuildPipeline.BuildAssetBundles(outPathDir, BuildAssetBundleOptions.UncompressedAssetBundle, BuildTarget.StandaloneWindows64);
            }
            catch(Exception e)
            {
                report = e.Message + "\n";
            }
            finally
            {
                AssetDatabase.Refresh();

                PrefabUtility.UnpackPrefabInstance(avatarAssetObj, PrefabUnpackMode.Completely, InteractionMode.UserAction);
                ScriptableObject.DestroyImmediate(avatarAssetObj, true);
                AssetDatabase.Refresh();

                ab_path = AssetDatabase.GetAssetPath(avatarAsset);

                asset = AssetImporter.GetAtPath(ab_path);

                asset.assetBundleName = string.Empty;

                asset.SaveAndReimport();
            }
            return report;
        }
        #endregion

        #region 制作asset 场景
        //sa    当前场景
        //.ask  后缀
        //BuildTarget.StandaloneWindows64   平台
        //BuildOptions.BuildAdditionalStreamedScenes | BuildOptions.UncompressedAssetBundle 打包方式
        public static string AssetScene(SceneAsset sa, string outPathDir, string puffix, BuildTarget buildTarget, BuildOptions buildOptions)
        {
            string report = string.Empty;
            try
            {
                BuildPipeline.BuildPlayer(new string[] { AssetDatabase.GetAssetPath(sa) }, $"{outPathDir}\\{sa.name}.{puffix}", buildTarget, buildOptions);
            }
            catch(Exception e)
            {
                report += e.Message + "\n";
            }
            return report;
        }

        #endregion

        #region 清除ab标签

        public static void RemoveABLabel()
        {
            // 需要移除标记的根目录
            string strNeedRemoveLabelRoot = string.Empty;
            // 目录信息（场景目录信息数组，表示所有根目录下场景目录）
            DirectoryInfo[] directoryDIRArray = null;


            // 定义需要移除AB标签的资源的文件夹根目录
            strNeedRemoveLabelRoot = Application.dataPath;
            //Debug.Log("strNeedSetLabelRoot = "+strNeedSetLabelRoot);

            DirectoryInfo dirTempInfo = new DirectoryInfo(strNeedRemoveLabelRoot);
            directoryDIRArray = dirTempInfo.GetDirectories();

            // 遍历本场景目录下所有的目录或者文件
            foreach (DirectoryInfo currentDir in directoryDIRArray)
            {
                // 递归调用方法，找到文件，则使用 AssetImporter 类，标记“包名”与 “后缀名”
                JudgeDirOrFileByRecursive(currentDir);
            }

            // 清空无用的 AB 标记
            AssetDatabase.RemoveUnusedAssetBundleNames();
            // 刷新
            AssetDatabase.Refresh();

            // 提示信息，标记包名完成
            //Debug.Log("AssetBundle 本次操作移除标记完成");

        }

        /// <summary>
        /// 递归判断判断是否是目录或文件
        /// 是文件，修改 Asset Bundle 标记
        /// 是目录，则继续递归
        /// </summary>
        /// <param name="fileSystemInfo">当前文件信息（文件信息与目录信息可以相互转换）</param>
        private static void JudgeDirOrFileByRecursive(FileSystemInfo fileSystemInfo)
        {
            // 调试信息
            //Debug.Log("currentDir.Name = " + fileSystemInfo.Name);
            //Debug.Log("sceneName = " + sceneName);

            // 参数检查
            if (fileSystemInfo.Exists == false)
            {
                Debug.LogError(FieldLNGConfig.file_or_dir_str + fileSystemInfo + FieldLNGConfig.no_value_check_str);
                return;
            }

            // 得到当前目录下一级的文件信息集合
            DirectoryInfo directoryInfoObj = fileSystemInfo as DirectoryInfo;           // 文件信息转为目录信息
            FileSystemInfo[] fileSystemInfoArray = directoryInfoObj.GetFileSystemInfos();

            foreach (FileSystemInfo fileInfo in fileSystemInfoArray)
            {
                FileInfo fileInfoObj = fileInfo as FileInfo;

                // 文件类型
                if (fileInfoObj != null)
                {
                    // 修改此文件的 AssetBundle 标签
                    RemoveFileABLabel(fileInfoObj);
                }
                // 目录类型
                else
                {

                    // 如果是目录，则递归调用
                    JudgeDirOrFileByRecursive(fileInfo);
                }
            }
        }

        /// <summary>
        /// 给文件移除 Asset Bundle 标记
        /// </summary>
        /// <param name="fileInfoObj">文件（文件信息）</param>
        static void RemoveFileABLabel(FileInfo fileInfoObj)
        {
            // 参数定义
            // AssetBundle 包名称
            string strABName = string.Empty;
            // 文件路径（相对路径）
            string strAssetFilePath = string.Empty;

            // 参数检查（*.meta 文件不做处理）
            if (fileInfoObj.Extension == ".meta" || fileInfoObj.Extension == ".cs")
            {
                return;
            }

            // 得到 AB 包名称
            strABName = string.Empty;
            // 获取资源文件的相对路径
            int tmpIndex = fileInfoObj.FullName.IndexOf("Assets");
            strAssetFilePath = fileInfoObj.FullName.Substring(tmpIndex);        // 得到文件相对路径


            // 给资源文件移除 AB 名称
            AssetImporter tmpImportObj = AssetImporter.GetAtPath(strAssetFilePath);
            tmpImportObj.assetBundleName = strABName;


        }

        #endregion

        #endregion
    }
}

