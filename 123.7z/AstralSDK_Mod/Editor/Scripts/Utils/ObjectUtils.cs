﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;

namespace ASK_SDK
{
    public class ObjectUtils 
    {
        public static T[] GetSceneType<T>() where T : UnityEngine.Object
        {
            return Resources.FindObjectsOfTypeAll<T>();
            //return UnityEditor.SceneView.FindObjectsOfType<T>();
        }

        public static T[] GetPrefabsType<T>(GameObject avatar) where T : UnityEngine.Object
        {
            if (avatar == null) return null;
            return avatar.GetComponentsInChildren<T>();
        }

        public static GameObject[] GetPrefabsGameObject(GameObject avatar) 
        {
            if (avatar == null) return null;

            List<GameObject> gameObjects = new List<GameObject>();

            GetChildGameObj(avatar.transform, gameObjects);

            return gameObjects.ToArray();
        }


        private static void GetChildGameObj(Transform trans, List<GameObject> list)
        {
            if (trans == null) return;

            foreach (Transform item in trans)
            {
                list.Add(item.gameObject);

                if(item.childCount > 0)
                {
                    GetChildGameObj(item, list);
                }
            }
        }

        private static List<Material> materials;
        private static List<Shader> shaders;
        private static List<Texture> textures;
        private static long texturesSize;
        private static List<AudioClip> audioClips;
        private static long audioClipsSize;
        private static List<VideoClip> videoClips;
        private static long videoClipsSize;

        public static List<Material> Materials => materials;
        public static List<Shader> Shaders => shaders;
        public static List<Texture> Textures => textures;
        public static long TexturesSize => texturesSize;
        public static List<AudioClip> AudioClips => audioClips;
        public static long AudioClipsSize => audioClipsSize;
        public static List<VideoClip> VideoClips => videoClips;
        public static long VideoClipsSize => videoClipsSize;


        public static void GetMaterials(MeshRenderer[] meshRenderers)
        {
            if (meshRenderers != null && meshRenderers.Length > 0)
            {
                foreach (var item in meshRenderers)
                {
                    foreach (var mt in item.sharedMaterials)
                    {
                        if (mt == null || materials.Contains(mt))
                        {
                            continue;
                        }

                        materials.Add(mt);

                        if (shaders.Contains(mt.shader))
                        {
                            continue;
                        }

                        shaders.Add(mt.shader);
                    }
                }
            }
        }

        public static void GetMaterials(SkinnedMeshRenderer[] skr)
        {
            if (skr != null && skr.Length > 0)
            {
                foreach (var ps in skr)
                {
                    foreach (var item in ps.sharedMaterials)
                    {
                        if(item != null && !materials.Contains(item))
                        {
                            materials.Add(item);

                            if (!shaders.Contains(item.shader))
                            {
                                shaders.Add(item.shader);
                            }
                        }
                    }
                }
            }
        }

        public static void GetMaterials(ParticleSystem[] particleSystems)
        {
            if (particleSystems != null && particleSystems.Length > 0)
            {
                foreach (var ps in particleSystems)
                {
                    if (ps.shape.meshRenderer == null)
                    {
                        continue;
                    }

                    foreach (var mt in ps.shape.meshRenderer.materials)
                    {
                        if (mt == null || materials.Contains(mt))
                        {
                            continue;
                        }

                        materials.Add(mt);

                        if (shaders.Contains(mt.shader))
                        {
                            continue;
                        }

                        shaders.Add(mt.shader);
                    }
                }
            }
        }

        /// <summary>
        /// 获取所有材质球和shader数量
        /// 自动去重
        /// </summary>
        /// <param name="meshRenderers">meshRenderer array</param>
        /// <param name="particleSystems">particleSystem array</param>
        public static void GetAllMaterials(MeshRenderer[] meshRenderers, ParticleSystem[] particleSystems, SkinnedMeshRenderer[] skrs)
        {
            materials = Check(materials);
            shaders = Check(shaders);

            GetMaterials(meshRenderers);
            GetMaterials(particleSystems);
            GetMaterials(skrs);
        }

        public static void GetAllAudioClips(AudioSource[] audioSources)
        {
            audioClips = Check(audioClips);
            audioClipsSize = 0;

            if (audioSources != null && audioSources.Length > 0)
            {
                foreach (var item in audioSources)
                {
                    if (item.clip != null && !audioClips.Contains(item.clip))
                    {
                        audioClips.Add(item.clip);
                        string path = UnityEditor.AssetDatabase.GetAssetPath(item.clip);
                        byte[] data = File.ReadAllBytes(Path.Combine(Application.dataPath.Replace("Assets", ""), path));
                        //Debug.Log(data.Length);
                        //Debug.Log(data.Length / 1024 / 1024 + "M");
                        audioClipsSize += data.Length;
                    }
                }

                Debug.Log(audioClipsSize / 1024 / 1024 + "M");
            }
        }

        public static void GetAllVideoClips(VideoPlayer[] videoPlayers)
        {
            videoClips = Check(videoClips);
            videoClipsSize = 0;

            if (videoPlayers != null && videoPlayers.Length > 0)
            {
                foreach (var vp in videoPlayers)
                {
                    if (vp.clip != null && !videoClips.Contains(vp.clip))
                    {
                        videoClips.Add(vp.clip);
                        string path = UnityEditor.AssetDatabase.GetAssetPath(vp.clip);
                        byte[] data = File.ReadAllBytes(Path.Combine(Application.dataPath.Replace("Assets", ""), path));
                        videoClipsSize += data.Length;
                    }
                }
            }
            Debug.Log(videoClipsSize / 1024 / 1024 + "M");
        }

        public static void GetAlltextures(GameObject[] all = null)
        {
            textures = Check(textures);

            //所有的材质里的图片
            foreach (var item in materials)
            {
                foreach (var id in item.GetTexturePropertyNameIDs())
                {
                    var texture = item.GetTexture(id);

                    if (textures.Contains(texture))
                    {
                        continue;
                    }

                    textures.Add(texture);
                } 
            }

            if(all != null)
            {
                foreach (var item in all)
                {
                    var images = item.GetComponents<Image>();
                    foreach (var img in images)
                    {
                        if(img.overrideSprite != null)
                        {
                            if(!textures.Contains(img.overrideSprite.texture))
                            {
                                textures.Add(img.overrideSprite.texture);
                            }
                        }
                    }

                    var raws = item.GetComponents<RawImage>();
                    foreach (var rawimg in raws)
                    {
                        if(rawimg.texture != null)
                        {
                            if (!textures.Contains(rawimg.texture))
                            {
                                textures.Add(rawimg.texture);
                            }
                        }
                    }

                    var lights = item.GetComponents<Light>();
                    foreach (var light in lights)
                    {
                        if(light.cookie != null)
                        {
                            if (!textures.Contains(light.cookie))
                            {
                                textures.Add(light.cookie);
                            }
                        }
                    }

                    var sbs = item.GetComponents<Scrollbar>();
                    foreach (var sb in sbs)
                    {
                        if(sb.targetGraphic != null && sb.targetGraphic.mainTexture != null)
                        {
                            if (!textures.Contains(sb.targetGraphic.mainTexture))
                            {
                                textures.Add(sb.targetGraphic.mainTexture);
                            }
                        }
                    }

                    var slders = item.GetComponents<Slider>();
                    foreach (var sb in slders)
                    {
                        if(sb.targetGraphic != null && sb.targetGraphic.mainTexture != null)
                        {
                            if (!textures.Contains(sb.targetGraphic.mainTexture))
                            {
                                textures.Add(sb.targetGraphic.mainTexture);
                            }
                        }
                    }

                    Toggle[] ts = item.GetComponents<Toggle>();
                    foreach (var sb in ts)
                    {
                        if (sb.targetGraphic != null && sb.targetGraphic.mainTexture != null)
                        {
                            if (!textures.Contains(sb.targetGraphic.mainTexture))
                            {
                                textures.Add(sb.targetGraphic.mainTexture);
                            }
                        }
                    }

                    var sms = item.GetComponents<SpriteMask>();
                    foreach (var sb in sms)
                    {
                        if(sb.sprite != null && sb.sprite.texture != null)
                        {
                            if (!textures.Contains(sb.sprite.texture))
                            {
                                textures.Add(sb.sprite.texture);
                            }
                        }
                    }
                }
            }
            

            //所有image组件的图片
            //所有rawimage组件的图片
            //所有light组件的图片
            //所有scrollbar组件的图片
            //所有toggle组件的图片
        }

        private static List<T> Check<T>(List<T> list)
        {
            if (list == null)
            {
                list = new List<T>();
            }
            else
            {
                list.Clear();
            }

            return list;
        }
    }
}

