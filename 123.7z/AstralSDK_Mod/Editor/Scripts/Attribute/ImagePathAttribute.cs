﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    [AttributeUsage( AttributeTargets.Field, AllowMultiple =false)]
    public class ImagePathAttribute : Attribute
    {
        private string assetPath = string.Empty;
        public string AssetPath => assetPath;

        public ImagePathAttribute(string assetPath)
        {
            this.assetPath = assetPath;
        }
    }
}

