﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = true)]
    public class TranslationAttribute : Attribute
    {
        private TranslationEnum m_enum;
        public TranslationEnum M_enum => m_enum;
        private string m_str;
        public string M_str => m_str;

        public TranslationAttribute(TranslationEnum @enum, string str)
        {
            m_enum = @enum;
            m_str = str;
        }
    }
}

