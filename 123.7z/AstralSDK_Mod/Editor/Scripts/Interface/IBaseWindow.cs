﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    public interface IBaseWindow 
    {
        void OnInit();

        void OnGUI();

        void OnRelease();
    }
}

