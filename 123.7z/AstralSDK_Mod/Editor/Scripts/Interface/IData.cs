﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    public interface IData
    {
        string Data_ID { get;  }
    }
}

