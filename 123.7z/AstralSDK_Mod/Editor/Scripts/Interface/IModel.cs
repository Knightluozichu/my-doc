﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    public interface IModel 
    {
        IData GetData();
        List<string> CheckData(IData data, out bool isSuccess);
    }
}

