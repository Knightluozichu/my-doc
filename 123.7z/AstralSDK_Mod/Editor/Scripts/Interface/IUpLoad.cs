﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASK_SDK
{
    interface IUpLoad
    {
        void Init();
        string Build();
        string UpLoad();
        void Release();
    }
}
