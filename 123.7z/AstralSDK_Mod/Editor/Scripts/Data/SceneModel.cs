﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ASK_SDK
{
    public class SceneModel : IModel
    {
        public SceneData sceneData;

        public SceneModel(SceneData sceneData)
        {
            this.sceneData = sceneData;
        }

        public SceneModel()
        {

        }

        public List<string> CheckData(IData data, out bool isSuccess)
        {
            isSuccess = true;
            return new List<string>() { };
        }

        public IData GetData()
        {
            return sceneData;
        }
    }
}

