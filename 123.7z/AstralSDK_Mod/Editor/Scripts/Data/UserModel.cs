﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    public class UserModel : IModel
    {

        public UserData mData;

        public UserModel(UserData mData)
        {
            this.mData = mData;
        }

        public UserModel()
        {

        }

        /// <summary>
        /// 初步检验用户名和密码
        /// 向服务器登录
        /// 获取响应数据
        /// </summary>
        /// <param name="data"></param>
        /// <param name="isSuccess"></param>
        /// <returns></returns>
        public List<string> CheckData(IData data, out bool isSuccess)
        {
            //todo..请求服务器登录响应
            isSuccess = true;
            this.mData.idAuthority = FieldLNGConfig.idAuthority_str;
            return new List<string>() { FieldLNGConfig.success_msg_str };
        }

        public void UnLogin()
        {
            this.mData.password = string.Empty;
            this.mData.idAuthority = string.Empty;
            Main.SetLogin(false);
        }

        public IData GetData()
        {
            return mData;
        }
    }
}

