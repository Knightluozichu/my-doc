﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    public class UpDataModel:IModel
    {
        public UpLoadData upLoadData;

        public UpDataModel(UpLoadData upLoadData)
        {
            this.upLoadData = upLoadData;
        }

        public UpDataModel()
        {

        }

        public List<string> CheckData(IData data, out bool isSuccess)
        {
            isSuccess = false;
            return new List<string>();
        }

        public IData GetData()
        {
            return upLoadData;
        }
    }
}

