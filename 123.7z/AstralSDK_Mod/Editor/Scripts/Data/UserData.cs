﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * 用户数据
 */

namespace ASK_SDK
{
    /// <summary>
    /// 用户名
    /// 用户密码
    /// 用户权限
    /// </summary>
    public struct UserData: IData
    {
        public string id;
        public string password;
        public string idAuthority;

        public string Data_ID { get => nameof(UserData); }
    }
}

