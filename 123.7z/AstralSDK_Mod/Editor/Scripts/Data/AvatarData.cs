﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace ASK_SDK
{

    public struct AvatarData : IData
    {
        public string avatar_name;
        public string avatar_preview_path;
        public string avatar_bg_path;
        public string avatar_show_path;
        public string avatar_introduction;
        public int avatar_property;
        public List<string> tag_keys;
        public string update_log;
        
        
        public string Data_ID { get { return nameof(AvatarData);  } }
    }
}

