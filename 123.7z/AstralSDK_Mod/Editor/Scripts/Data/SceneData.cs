﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace ASK_SDK
{
    public struct SceneData : IData
    {
        public string thumbnail_path;
        public string map_preview_path;
        public string map_name;
        public string url;
        public int map_capacity;
        public Rendering_Pipeline rendering_Pipeline;
        public List<string> tag_keys;
        public string introduction;
        public string update_log;


        public string Data_ID { get { return nameof(SceneData); } }
    }

    public enum Rendering_Pipeline
    {
        Bulit_in,
        URP,
    }
}

