﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ASK_SDK
{
    public class BShowInfo
    {
        public int id;
        public string str;
        public int num;
        public string p;
    }

}

