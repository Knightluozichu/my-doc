﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ASK_SDK
{
    public struct UpLoadData : IData
    {
        public bool is_up_Load;
        public string log_message;

        public string Data_ID => nameof(UpLoadData);
    }
}

