﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace ASK_SDK
{
    public class AssetWindow : BaseWindow, IBaseWindow
    {
        public static Dictionary<AssetRes, SubAssetWindowBase> dic_BaseAsset_win;
        private static SubAssetWindowBase currentSubWindow;
        public static SubAssetWindowBase CurrentSubWindow => currentSubWindow;


        //上传的是什么资源
        private static AssetRes upload_Res = AssetRes.Avatar;
        private static AssetRes last_upload_Res = AssetRes.Scene; 

        public static AssetRes Upload_Res { 
            set 
            {
                upload_Res = value;

                if (last_upload_Res != upload_Res)
                {
                    dic_BaseAsset_win[last_upload_Res].OnRelease();
                    last_upload_Res = upload_Res;
                    if (dic_BaseAsset_win.TryGetValue(upload_Res, out SubAssetWindowBase baseAsset))
                    {
                        currentSubWindow = baseAsset;
                        if (currentSubWindow != null)
                        {
                            currentSubWindow.OnInit();
                        }
                    }
                }
            } 
            get { return upload_Res; } 
        }


        private GUIContent[] assetwindow_guioContent;


        public void OnRelease()
        {
            if(currentSubWindow != null)
            {
                currentSubWindow.OnRelease();
            }
        }
       
        public void OnInit()
        {
            
            dic_BaseAsset_win = new Dictionary<AssetRes, SubAssetWindowBase>()
                {
                    {AssetRes.Scene, new BSceneAssetWindow()},
                    {AssetRes.Avatar, new BAvatarAssetWindow()},
                }; 
            
        }

        public void OnGUI()
        {

            assetwindow_guioContent = new GUIContent[] { new GUIContent() { text = FieldLNGConfig.avatar_str }, new GUIContent() { text = FieldLNGConfig.scene_str } };

            if (Main.IsLoaded)
            {

                using (gs = new GUI.GroupScope(new Rect(0, 50, Screen.width, 800f)))
                {
                    Upload_Res = (AssetRes)GUI.SelectionGrid(new Rect(250, 10, 300, 20), (int)Upload_Res, assetwindow_guioContent, assetwindow_guioContent.Length);
                }

                if(currentSubWindow != null)
                {
                    currentSubWindow.OnGUI();
                }
            }
            else
            {

            }
           
            GUI.DrawTexture(new Rect(0 - 10, (800 - 256 / 2) + 20, 256 / 2, 256 / 2), IconUtils.duck_login_1);
        }
    }
}

