﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ASK_SDK
{
    public class InfoWindow : BaseWindow, IBaseWindow
    {
        public static Dictionary<AssetRes, SubInfoWindowBase> dic_BaseAsset_win;

        private static SubInfoWindowBase currentWindow;
        public static SubInfoWindowBase CurrentWindow => currentWindow;
        public void OnRelease()
        {
            
        }

        public void OnInit()
        {
            dic_BaseAsset_win = new Dictionary<AssetRes, SubInfoWindowBase>()
                {
                    {AssetRes.Scene, new BSceneInfoWindow()},
                    {AssetRes.Avatar, new BAvatarInfoWindow()},
                };

            if(currentWindow != null)
            {
                currentWindow.OnRelease();
            }

            if(dic_BaseAsset_win.TryGetValue(AssetWindow.Upload_Res, out SubInfoWindowBase value))
            {
                if(currentWindow != null)
                {
                    currentWindow.OnRelease();
                }
                currentWindow = value;
                currentWindow.OnInit();
            }
        }
       

        public void OnGUI()
        {

            if (Main.IsLoaded)
            {

                using (gs = new GUI.GroupScope(new Rect(0, 30f, Screen.width, 680f)))
                {
                    GUI.Box(new Rect(200, 60, 400, 620), "", EditorStyles.helpBox);
                    EditorGUI.LabelField(new Rect(350, 20, 100, 40), new GUIContent(EditorGUIUtility.IconContent(AssetWindow.Upload_Res == AssetRes.Avatar ? "BodyPartPicker": "SceneAsset Icon")) { text = AssetWindow.Upload_Res == AssetRes.Avatar? FieldLNGConfig.avatar_info_str : FieldLNGConfig.scene_info_str }, new GUIStyle("AM HeaderStyle"));

                    using (gs = new GUI.GroupScope(new Rect(200, 60, 400, 600)))
                    {
                        if (currentWindow != null)
                        {
                            currentWindow.OnGUI();
                        }
                    }
                }
            }
            else
            {

            }
            

            GUI.DrawTexture(new Rect(0 - 10, (800 - 256 / 2) + 20, 256 / 2, 256 / 2), IconUtils.duck_seebook);
        }
    }
}

