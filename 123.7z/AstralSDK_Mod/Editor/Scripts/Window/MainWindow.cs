﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace ASK_SDK
{
    public class MainWindow : EditorWindow
    {
        private Vector2 win_min_size = new Vector2(800, 800);
        private Vector2 win_max_size = new Vector2(800, 800);

        private const string yizhen_descrition = "@2019-2021 I-Reality Network Technology Co.,Ltd. All Rights Reserved.";
        private const string com_logo_str = "logo";

        private GUIContent[] allContents;
        private int choose_bar_key = 0;
        private int last_bat_key = -1;
        private IBaseWindow currentWindow;

        

        public int Choose_bar_key
        {
            set
            {
                if(last_bat_key != choose_bar_key)
                {
                    if (Main.Dic_choose_window.TryGetValue(choose_bar_key, out IBaseWindow editorWindow))
                    {
                        last_bat_key = choose_bar_key;
                        if (currentWindow != null)
                        {
                            currentWindow.OnRelease();
                        }
                        currentWindow = editorWindow;
                        currentWindow.OnInit();
                    }
                }
                choose_bar_key = value;
            }

            get { return choose_bar_key; }
        }

        public void OnInit() 
        {
            this.autoRepaintOnSceneChange = false;
            this.maxSize = win_min_size;
            this.minSize = win_max_size;
            this.maximized = true;
            this.titleContent = new GUIContent() { image = IconUtils.duck_go_2, text = FieldLNGConfig.main_title_str };
        }


        //复用
        private GUI.GroupScope gs;

        

        private void OnGUI()
        {
            this.titleContent.text = FieldLNGConfig.main_title_str;
            allContents = new GUIContent[] { new GUIContent(FieldLNGConfig.login_str) { image = IconUtils.duck_login }, new GUIContent(FieldLNGConfig.main_asset_build_str) { image = IconUtils.duck_login_1 }, new GUIContent(FieldLNGConfig.main_info_str) { image = IconUtils.duck_seebook }, new GUIContent(FieldLNGConfig.main_upload_str) { image = IconUtils.duck_go_3 } };

            using (gs = new GUI.GroupScope(new Rect(0, 0, Screen.width,60)))
            {
                Choose_bar_key = GUI.Toolbar(new Rect(0,0, Screen.width, 40), Choose_bar_key, !Main.IsLoaded ? new GUIContent[] { allContents[0] } : allContents);
            }

            

            using (gs = new GUI.GroupScope(new Rect(0, 50, Screen.width, 800)))
            {
                GUI.Box(new Rect(0, 30, Screen.width, 650), ""); 
            }

            using (gs = new GUI.GroupScope(new Rect(350.49f, 678.4f, Screen.width,200)))
            {
                GUI.Label(new Rect(-360.1f, 101.4f, Screen.width, 20), new GUIContent { image = IconUtils.duck_seebook, text = yizhen_descrition, tooltip = com_logo_str }, new GUIStyle() { alignment = TextAnchor.LowerRight });
            }

            if (currentWindow != null)
            {
                currentWindow.OnGUI();
            }

            EditorGUI.LabelField(new Rect((Screen.width - 140), 40, 140, 20), new GUIContent(EditorGUIUtility.IconContent("_Popup")) { text = FieldLNGConfig.language_str });
            Main.Language = (TranslationEnum)EditorGUI.EnumPopup(new Rect(Screen.width - 60, 40, 60, 20),Main.Language, EditorStyles.popup);
            EditorGUI.LabelField(new Rect((Screen.width - 140), 40, 140, 20), "", StyleUtils.GetLine());
        }


        private void OnDestroy()
        {
            if (currentWindow != null)
            {
                currentWindow.OnRelease();
            }
        }
    }
}

