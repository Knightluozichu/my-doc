﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ASK_SDK
{
    public class LoginWindow : BaseWindow, IBaseWindow
    {
        
        private bool isShowPwd;

        private const string icon_show_str = "animationvisibilitytoggleon";
        private const string icon_hidden_str = "animationvisibilitytoggleoff";
        private const string icon_use_str = "SoftlockProjectBrowser Icon";
        private char psd_word = '*';

        //释放
        public void OnRelease()
        {
            //userModel = null; 
            isShowPwd = default(bool);
        }

        //初始化
        public void OnInit()
        {
            if (!Main.IsLoaded)
            {
                model = new UserModel(new UserData() { id = string.Empty, password = string.Empty, idAuthority = string.Empty });
            }
        }

        //渲染
        public void OnGUI()
        {
            if (!Main.IsLoaded)
            {
                NoLoadGUI();
            }
            else
            {
                IsLoadedGUI(); 
            }

            GUI.DrawTexture(new Rect(0 - 30, (800 - 256 / 2) + 20, 256 / 2, 256 / 2), IconUtils.duck_login);
        }

        //已登录 
        private void IsLoadedGUI()
        {
            using (gs = new GUI.GroupScope(new Rect(250, 315, 300, 170)))
            {
                GUI.Label(new Rect(new Rect(0, 0, 300, 20)), EditorGUIUtility.IconContent(icon_use_str));
                GUI.Box(new Rect(new Rect(0, 20, 300, 150)), ((UserModel)model).mData.id + "\n" + ((UserModel)model).mData.idAuthority, StyleUtils.GetStyle("flow node 3 on"));

                if (GUI.Button(new Rect(110, 130, 80, 20), new GUIContent(FieldLNGConfig.unlogin_str)))
                {
                    //todo..注销
                    ((UserModel)model).UnLogin();
                }
            }
        }

        //未登录
        private void NoLoadGUI()
        {
            using( gs = new GUI.GroupScope(new Rect(0, 100, Screen.width, 600)))
            {
                GUI.DrawTexture(new Rect(272, 100, 256,256), IconUtils.login_bg);

                GUI.Label(new Rect(178.6f, 450.06f, 100, 20), FieldLNGConfig.id_str);

                ((UserModel)model).mData.id = GUI.TextField(new Rect(178.6f + 60 + 20, 450.06f, 300, 20), ((UserModel)model).mData.id);

                GUI.Label(new Rect(178.6f , 450.06f + 26.72f, 100, 20), FieldLNGConfig.psd_str);

                isShowPwd = GUI.Toggle(new Rect(178.6f + 320 + 60 +10 , 450.06f + 26.72f, 300, 20), isShowPwd, EditorGUIUtility.IconContent(isShowPwd ? icon_show_str : icon_hidden_str));

                if (isShowPwd)
                {
                    ((UserModel)model).mData.password = GUI.TextField(new Rect(178.6f + 60 +20 , 450.06f + 26.72f, 300, 20), ((UserModel)model).mData.password);
                }
                else
                {
                    ((UserModel)model).mData.password = GUI.PasswordField(new Rect(178.6f + 60 + 20 , 450.06f + 26.72f, 300, 20), ((UserModel)model).mData.password, psd_word);
                }

                if (GUI.Button(new Rect(178.6f + 60 + 20, 450.06f + 26.72f + 50f, 300, 20), new GUIContent(FieldLNGConfig.login_str)))
                {
                    //todo..登录
                    model.CheckData(((UserModel)model).mData, out bool isSuccessed);
                    Main.SetLogin(isSuccessed);
                }
            }
        }

    }
}

