﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace ASK_SDK
{
    public abstract class BaseWindow 
    {
        public IModel model;

        protected GUI.GroupScope gs;

    }
}

