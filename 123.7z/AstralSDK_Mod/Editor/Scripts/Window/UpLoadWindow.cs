﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ASK_SDK
{
    public class UpLoadWindow : BaseWindow, IBaseWindow
    {
        private Dictionary<AssetRes, IUpLoad> m_sub_up_load;
        private IUpLoad currentUpLoad;

        private string log = string.Empty;

        public void OnRelease()
        {
            log = string.Empty;
        }

        public void OnInit()
        {
            log = string.Empty;

            if (model == null)
            {
                model = new UpDataModel(new UpLoadData()
                {
                    is_up_Load = false,
                    log_message = string.Empty
                });
            }
            
            if(m_sub_up_load == null)
            {
                m_sub_up_load = new Dictionary<AssetRes, IUpLoad>()
                {
                    {AssetRes.Avatar, new BAvatarUpLoadWindow() },
                    { AssetRes.Scene, new BSceneUpLoadWindow() }
                };
            }

            if(currentUpLoad != null)
            {
                currentUpLoad.Release();
            }

            currentUpLoad = m_sub_up_load[AssetWindow.Upload_Res];

            currentUpLoad.Init();
        }

        public void OnGUI()
        {
            using (gs = new GUI.GroupScope(new Rect(0, 80f, Screen.width, 680f)))
            {
                //打包
                if(GUI.Button(new Rect(250, 60, 300, 25), new GUIContent() { text = FieldLNGConfig.upload_build_str, image = IconUtils.onion }, StyleUtils.GetStyle(EditorStyles.miniButton.name)))
                {

                    if(currentUpLoad != null)
                    {
                        log = currentUpLoad.Build();

                        if(!string.IsNullOrEmpty(log))
                        {
                            ((UpDataModel)model).upLoadData.log_message += log;
                        }
                        else
                        {
                            ((UpDataModel)model).upLoadData.log_message += FieldLNGConfig.upload_build_sccess_str + "\n";
                        }
                    }
                }

                //上传
                if(GUI.Button(new Rect(250,100,300,25),new GUIContent() {text= FieldLNGConfig.upload_load_str, image = IconUtils.roasted_chicken_drumsticks }, StyleUtils.GetStyle(EditorStyles.miniButton.name)))
                {

                    if (currentUpLoad != null)
                    {
                        log =  currentUpLoad.UpLoad();
                        if (!string.IsNullOrEmpty(log))
                        {
                            ((UpDataModel)model).upLoadData.log_message += log;
                        }
                        else
                        {
                            ((UpDataModel)model).upLoadData.log_message += FieldLNGConfig.upload_upload_sccess_str + "\n";
                        }
                            
                    }
                }

                //信息日志
                EditorGUI.LabelField(new Rect(10, 125, 300, 20), new GUIContent() { image = IconUtils.barbecue, text = FieldLNGConfig.upload_log_str }, new GUIStyle(EditorStyles.label) { alignment = TextAnchor.MiddleLeft });
                GUI.Box(new Rect(10, 145, Screen.width-20, 500), "", EditorStyles.helpBox);
                EditorGUI.SelectableLabel(new Rect(10, 145, Screen.width-20, 500), ((UpDataModel)model).upLoadData.log_message, StyleUtils.GetStyle(EditorStyles.wordWrappedMiniLabel.name, TextAnchor.UpperLeft)) ;
            }

            GUI.DrawTexture(new Rect(0, (800 - 629 / 4) + 5, 397 / 4, 629 / 4), IconUtils.duck_go_3);
        }
    }
}

