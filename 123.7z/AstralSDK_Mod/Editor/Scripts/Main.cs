﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;

namespace ASK_SDK
{
    public enum AssetRes
    {
        Avatar,
        Scene
    }

    public class Main
    {
        //窗体驱动
        private static Dictionary<int, IBaseWindow> dic_choose_window;
        //是否登录
        private static bool isLoaded;

        public static bool IsLoaded => isLoaded;

        public static void SetLogin(bool isSuccessed)
        {
            isLoaded = isSuccessed;
        }

        private static TranslationEnum lastLanuge;
        private static TranslationEnum language;
        public static TranslationEnum Language { get
            {
                return language;
            }
            set 
            {
                if(lastLanuge != language)
                {
                    lastLanuge = language;
                    AttributeUtils.GetTranslationAttribute(language);
                }

                language = value;
            } 
        }
        public static Dictionary<int, IBaseWindow> Dic_choose_window  
        {
            get
            {
                if(dic_choose_window == null)
                {
                    dic_choose_window = new Dictionary<int, IBaseWindow>()
                    {
                        {0, new LoginWindow()},
                        {1, new AssetWindow()},
                        {2, new InfoWindow()},
                        {3, new UpLoadWindow()}
                    };
                }
                return dic_choose_window;
            }
        }

        

        //[InitializeOnLoadMethod]


        //[InitializeOnLoadMethod]
        [MenuItem("Custom Editor/ASKTools")]
        public static void Init()
        {
            //初始化数据
            //打开主窗口
            Debug.Log(Application.systemLanguage);
            language = (TranslationEnum)Application.systemLanguage;
            AttributeUtils.GetTranslationAttribute(language);
            //return;
            AttributeUtils.GetIconDataAttribute();

            MainWindow mainwindow =  EditorWindow.GetWindow<MainWindow>();
            mainwindow.OnInit();
            mainwindow.Show();
        }
    }
}

